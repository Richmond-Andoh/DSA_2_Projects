public class DeliveryNode {
    Delivery data;
    DeliveryNode next;

    public DeliveryNode(Delivery data) {
        this.data = data;
        this.next = null;
    }
}
